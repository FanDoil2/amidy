package com.example.acgbuczynski;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
    private Figury figura1;
    private Figury figura2;
    private Figury figura3;
    private Figury figura4;
    private Figury figura5;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        figura1 = findViewById(R.id.view);
        figura2 = findViewById(R.id.view2);
        figura3 = findViewById(R.id.view3);
        figura4 = findViewById(R.id.view4);
        figura5 = findViewById(R.id.view5);
    }
}