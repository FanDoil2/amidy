package com.example.acgbuczynski;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.Random;

public class Figury extends View {

    private Random r;
    private int[] loskol;
    private int[] losroz;
    private int liczbaFigur;
    public Figury(Context context, AttributeSet attrs) {
        super(context, attrs);
        r = new Random();
        generateNewShapes();
    }
    public Figury(Context context) {
        super(context);
    }
    private void generateNewShapes() {
        liczbaFigur = 4 + r.nextInt(6);
        loskol = new int[liczbaFigur];
        losroz = new int[liczbaFigur];
        for (int i = 0; i < liczbaFigur; i++) {
            loskol[i] = Color.argb(255, r.nextInt(256), r.nextInt(256), r.nextInt(256));
            losroz[i] = 30 + r.nextInt(200);
        }
    }
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int szer = getWidth();
        int wys = getHeight();
        Paint p = new Paint();
        p.setAntiAlias(true);
        p.setColor(Color.rgb(0,0,0));
        canvas.drawRect(0, 0, szer, wys, p);
        CharSequence opis = getContentDescription();
        if (opis == null) {
            opis = "brak";
        }
        for (int i = 0; i < liczbaFigur; i++) {
            p.setColor(loskol[i]);
            int rozmiar = losroz[i];
            int x = r.nextInt(szer - rozmiar);
            int y = r.nextInt(wys - rozmiar);
            if (opis.equals("koło")) {
                canvas.drawCircle(x + rozmiar / 2, y + rozmiar / 2, rozmiar / 2, p);
            } else if (opis.equals("elipsa")) {
                RectF oval = new RectF(x, y, x + rozmiar, y + rozmiar / 2);
                canvas.drawOval(oval, p);
            } else if (opis.equals("prostokąt")) {
                RectF rect = new RectF(x, y, x + rozmiar, y + rozmiar);
                canvas.drawRect(rect, p);
            } else if (opis.equals("łuk")) {
                RectF rect = new RectF(x, y, x + rozmiar, y + rozmiar);
                canvas.drawArc(rect, r.nextInt(360), r.nextInt(180), false, p);
            } else if (opis.equals("linia")) {
                int dx = r.nextInt(szer);
                int dy = r.nextInt(wys);
                canvas.drawLine(x, y, dx, dy, p);
            }
        }
        p.setTextSize(50);
        p.setTextAlign(Paint.Align.RIGHT);
        p.setColor(Color.WHITE);
        canvas.drawText((String) opis, szer - 20, wys / 2, p);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            generateNewShapes();
            invalidate();
            return true;            }
        return super.onTouchEvent(event);
    }
}
